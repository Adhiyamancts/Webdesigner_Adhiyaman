$(document).ready(function(){
$( ".theme_change" ).on("click", function() {
		if( $( "body" ).hasClass( "dark" )) {
			$( "body" ).removeClass( "dark" );
			$( ".theme_change" ).text( "Dark" );
		} else {
			$( "body" ).addClass( "dark" );
			$( ".theme_change" ).text( "Light" );
		}
	});
var animations = function() {
    var offset = $(window).scrollTop() + $(window).height(),
        $animatables = $('.animatable');
    if ($animatables.length == 0) {
      $(window).off('scroll', animations);
    }
		$animatables.each(function(i) {
       var $animatable = $(this);
			if (($animatable.offset().top + $animatable.height() - 20) < offset) {
        $animatable.removeClass('animatable').addClass('animated');
			}
    });

	};
	$(window).on('scroll', animations);
    $(window).trigger('scroll');
});




